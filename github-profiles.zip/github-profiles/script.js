const URL_API = "https://api.github.com/users/";

const principal = document.getElementById("main");
const formulario = document.getElementById("form");
const busca = document.getElementById("search");

// Função para buscar dados do usuário
async function buscarUsuario(nomeUsuario) {
  try {
    const { data } = await axios(URL_API + nomeUsuario);

    criarCartaoUsuario(data);
    buscarRepositorios(nomeUsuario);
  } catch (erro) {
    if (erro.response.status == 404) {
      criarCartaoErro("Nenhum perfil encontrado com esse nome de usuário");
    }
  }
}

// Função para buscar repositórios do usuário
async function buscarRepositorios(nomeUsuario) {
  try {
    const { data } = await axios(URL_API + nomeUsuario + "/repos?sort=created");

    adicionarReposAoCartao(data);
  } catch (erro) {
    criarCartaoErro("Problema ao buscar os repositórios");
  }
}

// Função para criar o cartão com informações do usuário
function criarCartaoUsuario(usuario) {
  const nomeID = usuario.name || usuario.login;
  const biografia = usuario.bio ? `<p>${usuario.bio}</p>` : "";
  const htmlCartao = `
    <div class="card">
        <div>
            <img src="${usuario.avatar_url}" alt="${usuario.name}" class="avatar">
        </div>
        <div class="user-info">
            <h2>${nomeID}</h2>
            ${biografia}
            <ul>
                <li>${usuario.followers} <strong>Seguidores</strong></li>
                <li>${usuario.following} <strong>Seguindo</strong></li>
                <li>${usuario.public_repos} <strong>Repositórios</strong></li>
            </ul>
            <div id="repos"></div>
        </div>
    </div>
    `;
  principal.innerHTML = htmlCartao;
}

// Função para criar cartão de erro
function criarCartaoErro(mensagem) {
  const htmlCartao = `
        <div class="card">
            <h1>${mensagem}</h1>
        </div>
    `;
  principal.innerHTML = htmlCartao;
}

// Função para adicionar repositórios ao cartão
function adicionarReposAoCartao(repositorios) {
  const elementoRepos = document.getElementById("repos");

  repositorios.slice(0, 5).forEach((repositorio) => {
    const linkRepo = document.createElement("a");
    linkRepo.classList.add("repo");
    linkRepo.href = repositorio.html_url;
    linkRepo.target = "_blank";
    linkRepo.innerText = repositorio.name;

    elementoRepos.appendChild(linkRepo);
  });
}

// Evento de envio do formulário
formulario.addEventListener("submit", (evento) => {
  evento.preventDefault();

  const usuario = busca.value;

  if (usuario) {
    buscarUsuario(usuario);
    busca.value = "";
  }
});
