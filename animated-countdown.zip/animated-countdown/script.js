document.addEventListener("DOMContentLoaded", function () {
  const input = document.getElementById("inputCount");
  const currentCount = document.getElementById("currentCount");
  const remainingCount = document.getElementById("remainingCount");
  const startButton = document.getElementById("startButton");
  const resetButton = document.getElementById("resetButton");
  const progressBar = document.getElementById("progress");
  const celebrateMessage = document.getElementById("celebrate");

  let count = 0;
  const target = 1000000;
  let interval;

  function updateDisplay() {
    currentCount.textContent = count.toLocaleString("pt-BR");
    remainingCount.textContent = (target - count).toLocaleString("pt-BR");

    const progressPercent = Math.min((count / target) * 100, 100);
    progressBar.style.width = `${progressPercent}%`;

    if (count >= target) {
      celebrateMessage.classList.add("show");
    } else {
      celebrateMessage.classList.remove("show");
    }
  }

  startButton.addEventListener("click", function () {
    const inputValue = parseInt(input.value);
    if (isNaN(inputValue) || inputValue < 0 || inputValue >= target) {
      alert("Digite um número válido menor que 1.000.000");
      return;
    }

    count = inputValue;
    updateDisplay();

    clearInterval(interval);
    interval = setInterval(() => {
      if (count < target) {
        count += 1000;
        updateDisplay();
      } else {
        clearInterval(interval);
      }
    }, 100);
  });

  resetButton.addEventListener("click", function () {
    clearInterval(interval);
    count = 0;
    input.value = "";
    updateDisplay();
  });

  // Inicializa a interface
  updateDisplay();
});
