const toggles = document.querySelectorAll(".faq-toggle");

toggles.forEach((toggle) => {
  toggle.addEventListener("click", () => {
    const faq = toggle.parentNode;
    const isActive = faq.classList.toggle("active");

    // Atualiza aria-expanded no botão
    toggle.setAttribute("aria-expanded", isActive);

    // Atualiza aria-hidden no texto
    const answerId = toggle.getAttribute("aria-controls");
    const answer = document.getElementById(answerId);
    if (answer) {
      answer.setAttribute("aria-hidden", !isActive);
    }
  });
});
