const form = document.getElementById("form");
const input = document.getElementById("input");
const todosUL = document.getElementById("todos");

// Carrega tarefas do localStorage
const todos = JSON.parse(localStorage.getItem("todos"));

if (todos) {
  todos.forEach((todo) => addTodo(todo));
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  addTodo();
});

function addTodo(todo) {
  let todoText = input.value;

  if (todo) {
    todoText = todo.text;
  }

  if (todoText) {
    // Cria o elemento da tarefa
    const todoEl = document.createElement("li");
    todoEl.classList.add("task-card"); // Estilo futurista

    // Checkbox
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.classList.add("task-check");
    checkbox.checked = todo?.completed || false;

    // Texto da tarefa
    const span = document.createElement("span");
    span.classList.add("task-text");
    span.innerText = todoText;

    // Botão de deletar
    const deleteBtn = document.createElement("button");
    deleteBtn.classList.add("delete-btn");
    deleteBtn.innerText = "✕";

    // Marca como concluída
    if (todo && todo.completed) {
      todoEl.classList.add("completed");
    }

    checkbox.addEventListener("change", () => {
      todoEl.classList.toggle("completed");
      updateLS();
    });

    deleteBtn.addEventListener("click", () => {
      todoEl.remove();
      updateLS();
    });

    // Monta o cartão
    todoEl.appendChild(checkbox);
    todoEl.appendChild(span);
    todoEl.appendChild(deleteBtn);

    // Adiciona animação de entrada
    todoEl.style.opacity = "0";
    todosUL.appendChild(todoEl);
    setTimeout(() => {
      todoEl.style.opacity = "1";
      todoEl.style.transition = "opacity 0.3s ease";
    }, 10);

    input.value = "";
    updateLS();
  }
}

function updateLS() {
  const todosEl = document.querySelectorAll(".task-card");

  const todos = [];

  todosEl.forEach((todoEl) => {
    const text = todoEl.querySelector(".task-text").innerText;
    const completed = todoEl.classList.contains("completed");

    todos.push({ text, completed });
  });

  localStorage.setItem("todos", JSON.stringify(todos));
}
