const boxesContainer = document.getElementById("boxes");
const btn = document.getElementById("btn");

btn.addEventListener("click", () => {
  boxesContainer.classList.toggle("big");
});

function createBoxes() {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const box = document.createElement("div");
      box.classList.add("box");

      // Posição da imagem
      box.style.backgroundPosition = `${-col * 50}px ${-row * 50}px`;

      // Valores aleatórios para espalhar
      const randomX = Math.floor(Math.random() * 500 - 250); // entre -250 e 250
      const randomY = Math.floor(Math.random() * 500 - 250); // entre -250 e 250
      box.style.setProperty("--x", randomX);
      box.style.setProperty("--y", randomY);

      boxesContainer.appendChild(box);
    }
  }
}

createBoxes();
