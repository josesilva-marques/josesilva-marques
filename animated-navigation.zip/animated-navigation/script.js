function toggleNav() {
  nav.classList.toggle("active");
}

toggle.addEventListener("click", toggleNav);
