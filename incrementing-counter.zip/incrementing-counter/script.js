const counters = document.querySelectorAll(".counter");

// Função de animação do contador
function animateCounter(counter) {
  counter.innerText = "0";

  const updateCounter = () => {
    const target = +counter.getAttribute("data-target");
    const speed = +counter.getAttribute("data-speed") || 200; // velocidade padrão
    const current = +counter.innerText;

    const increment = Math.ceil(target / speed);

    if (current < target) {
      counter.innerText = `${current + increment}`;
      requestAnimationFrame(updateCounter); // animação suave
    } else {
      counter.innerText = target;
      counter.classList.add("pulse"); // efeito pulsar ao finalizar
    }
  };

  updateCounter();
}

// Intersection Observer → só inicia quando o contador aparece na tela
const observer = new IntersectionObserver(
  (entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target); // anima apenas uma vez
      }
    });
  },
  { threshold: 0.6 } // dispara quando 60% do elemento está visível
);

// Observa cada contador
counters.forEach((counter) => {
  observer.observe(counter);
});
