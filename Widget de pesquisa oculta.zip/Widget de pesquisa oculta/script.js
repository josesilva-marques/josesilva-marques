const procurar = document.querySelector(".procurar");
const btn = document.querySelector(".btn");
const input = document.querySelector(".input");

btn.addEventListener("click", () => {
  procurar.classList.toggle("active");
  input.focus();
});
if (window.innerWidth > 768) {
  input.focus();
}
btn.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    procurar.classList.toggle("active");
    input.focus();
  }
});
