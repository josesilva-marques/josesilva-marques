// Seleciona os elementos do DOM
const testimonial = document.querySelector(".testimonial");
const userImage = document.querySelector(".user-image");
const username = document.querySelector(".username");
const role = document.querySelector(".role");
const filter = document.getElementById("category-filter");

// Lista de depoimentos
const testimonials = [
  {
    name: "Miyah Myles",
    position: "Marketing",
    photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    text: "I've worked with literally hundreds of HTML/CSS developers and I have to say the top spot goes to this guy. He stresses on good, clean code and pays attention to the details. He goes over and beyond and transforms ART into PIXELS - without a glitch, every time.",
  },
  {
    name: "June Cha",
    position: "Software Engineer",
    photo: "https://randomuser.me/api/portraits/women/44.jpg",
    text: "This guy is an amazing frontend developer that delivered the task exactly how we needed it. He will go the extra mile to make sure you're happy with your project.",
  },
  {
    name: "Iida Niskanen",
    position: "Data Entry",
    photo: "https://randomuser.me/api/portraits/women/68.jpg",
    text: "This guy is a hard worker. Communication was also very good with him and he was very responsive all the time. We'll definitely repeat with him.",
  },
  {
    name: "Renee Sims",
    position: "Receptionist",
    photo: "https://randomuser.me/api/portraits/women/65.jpg",
    text: "This guy does everything he can to get the job done and done right. This is the second time I've hired him, and I'll hire him again in the future.",
  },
  {
    name: "Jonathan Nunfiez",
    position: "Graphic Designer",
    photo: "https://randomuser.me/api/portraits/men/43.jpg",
    text: "I had my concerns that due to a tight deadline this project couldn't be done. But this guy proved me wrong. Outstanding work delivered early!",
  },
  {
    name: "Sasha Ho",
    position: "Accountant",
    photo:
      "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?h=350&auto=compress&cs=tinysrgb",
    text: "This guy is a top notch designer and front end developer. He communicates well, works fast and produces quality work.",
  },
  {
    name: "Veeti Seppanen",
    position: "Director",
    photo: "https://randomuser.me/api/portraits/men/97.jpg",
    text: "This guy is a young and talented IT professional, proactive and responsible, with a strong work ethic. He is focused and delivers outstanding results.",
  },
];

// Inicializa com todos os depoimentos
let filteredTestimonials = [...testimonials];
let idx = 0;

// Atualiza o conteúdo do depoimento
function updateTestimonial() {
  if (filteredTestimonials.length === 0) {
    testimonial.innerHTML = "Nenhum depoimento encontrado para essa categoria.";
    userImage.src = "";
    username.innerHTML = "";
    role.innerHTML = "";
    return;
  }

  const { name, position, photo, text } = filteredTestimonials[idx];
  testimonial.innerHTML = text;
  userImage.src = photo;
  username.innerHTML = name;
  role.innerHTML = position;

  idx = (idx + 1) % filteredTestimonials.length;
}

// Atualiza a lista filtrada ao mudar o filtro
filter.addEventListener("change", () => {
  const selected = filter.value;
  filteredTestimonials =
    selected === "all"
      ? [...testimonials]
      : testimonials.filter((t) => t.position === selected);
  idx = 0;
  updateTestimonial();
});

// Inicia o carrossel
updateTestimonial();
setInterval(updateTestimonial, 10000);
