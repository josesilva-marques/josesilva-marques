// Seleciona o elemento com id 'container' onde os quadrados serão inseridos
const container = document.getElementById("container");

// Define um array com cores vibrantes para os efeitos visuais
const colors = ["#e74c3c", "#8e44ad", "#3498db", "#e67e22", "#2ecc71"];

// Define a quantidade total de quadrados a serem criados
const SQUARES = 500;

// Loop que cria os 500 quadrados
for (let i = 0; i < SQUARES; i++) {
  // Cria um novo elemento <div> para representar um quadrado
  const square = document.createElement("div");

  // Adiciona a classe 'square' para aplicar os estilos CSS
  square.classList.add("square");

  // Adiciona um ouvinte de evento para quando o mouse passar por cima do quadrado
  square.addEventListener("mouseover", () => setColor(square));

  // Adiciona um ouvinte de evento para quando o mouse sair do quadrado
  square.addEventListener("mouseout", () => removeColor(square));

  // Insere o quadrado dentro do contêiner na página
  container.appendChild(square);
}

// Função que aplica uma cor aleatória e efeito de brilho ao quadrado
function setColor(element) {
  // Obtém uma cor aleatória do array 'colors'
  const color = getRandomColor();

  // Define a cor de fundo do quadrado
  element.style.background = color;

  // Aplica uma sombra com brilho usando a mesma cor
  element.style.boxShadow = `0 0 2px ${color}, 0 0 10px ${color}`;
}

// Função que remove a cor e o brilho, restaurando o estilo original
function removeColor(element) {
  // Volta para a cor de fundo padrão escura
  element.style.background = "#1d1d1d";

  // Aplica uma sombra discreta
  element.style.boxShadow = "0 0 2px #000";
}

// Função que retorna uma cor aleatória do array 'colors'
function getRandomColor() {
  // Gera um índice aleatório e retorna a cor correspondente
  return colors[Math.floor(Math.random() * colors.length)];
}
