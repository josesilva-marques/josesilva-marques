const insert = document.getElementById("insert");

window.addEventListener("keydown", (event) => {
  insert.innerHTML = `
  <div class="key">
  ${event.key === " " ? "Space" : event.key} 
  <small>event.key</small>
</div>

<div class="key">
  ${event.keyCode}
  <small>event.keyCode</small>
</div>

<div class="key">
  ${event.code}
  <small>event.code</small>
</div>
  `;
});
document.addEventListener("keydown", (event) => {
  const keyElement = document.querySelector(".key");
  keyElement.classList.remove("key"); // remove para reiniciar animação
  void keyElement.offsetWidth; // força reflow
  keyElement.classList.add("key"); // reaplica classe com animação
});
