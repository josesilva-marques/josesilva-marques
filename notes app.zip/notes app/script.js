// Pega os elementos da página
const noteInput = document.getElementById("noteInput");
const saveBtn = document.getElementById("saveBtn");
const notesList = document.getElementById("notesList");

// Função para mostrar as notas salvas
function showNotes() {
  // Pega as notas do armazenamento do navegador
  let notes = localStorage.getItem("notes");
  if (notes) {
    notes = JSON.parse(notes);
  } else {
    notes = [];
  }

  // Limpa a lista para mostrar de novo
  notesList.innerHTML = "";

  // Mostra cada nota na tela
  notes.forEach((note, index) => {
    const noteDiv = document.createElement("div");
    noteDiv.className = "note";
    noteDiv.textContent = note;

    // Botão para apagar a nota
    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Apagar";
    deleteBtn.style.marginLeft = "10px";
    deleteBtn.onclick = () => {
      deleteNote(index);
    };

    noteDiv.appendChild(deleteBtn);
    notesList.appendChild(noteDiv);
  });
}

// Função para salvar uma nota
function saveNote() {
  const noteText = noteInput.value.trim();
  if (noteText === "") {
    alert("Escreva alguma coisa antes de salvar!");
    return;
  }

  let notes = localStorage.getItem("notes");
  if (notes) {
    notes = JSON.parse(notes);
  } else {
    notes = [];
  }

  notes.push(noteText);
  localStorage.setItem("notes", JSON.stringify(notes));
  noteInput.value = "";
  showNotes();
}

// Função para apagar uma nota
function deleteNote(index) {
  let notes = localStorage.getItem("notes");
  if (notes) {
    notes = JSON.parse(notes);
  } else {
    notes = [];
  }

  notes.splice(index, 1);
  localStorage.setItem("notes", JSON.stringify(notes));
  showNotes();
}

// Quando clicar no botão, salva a nota
saveBtn.addEventListener("click", saveNote);

// Mostrar as notas quando abrir a página
showNotes();
