let draggedFood = null;
let score = 0;
let timeLeft = 30;
let timerInterval;

// Referências aos elementos da interface
const scoreDisplay = document.getElementById("score");
const timerDisplay = document.getElementById("timer");
const message = document.getElementById("message");
const resetBtn = document.getElementById("resetBtn");

// Inicia o cronômetro
function startTimer() {
  timerInterval = setInterval(() => {
    timeLeft--;
    timerDisplay.textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      endGame();
    }
  }, 1000);
}

// Finaliza o jogo
function endGame() {
  document.querySelectorAll(".food").forEach((food) => {
    food.setAttribute("draggable", "false");
  });
  message.textContent =
    score === 5
      ? "Parabéns! Você montou um prato saudável! 🎉"
      : "Tempo esgotado! Tente novamente. ⏳";
}

// Reinicia o jogo
function resetGame() {
  score = 0;
  timeLeft = 30;
  scoreDisplay.textContent = score;
  timerDisplay.textContent = timeLeft;
  message.textContent = "";

  // Reposiciona os alimentos
  document.querySelectorAll(".food").forEach((food) => {
    document.querySelector(".foods").appendChild(food);
    food.setAttribute("draggable", "true");
  });

  // Limpa seções preenchidas
  document.querySelectorAll(".section").forEach((section) => {
    const foodInside = section.querySelector(".food");
    if (foodInside) section.removeChild(foodInside);
  });

  clearInterval(timerInterval);
  startTimer();
}

// Eventos de arrastar
document.querySelectorAll(".food").forEach((food) => {
  food.addEventListener("dragstart", () => {
    draggedFood = food;
    food.classList.add("dragging");
  });

  food.addEventListener("dragend", () => {
    food.classList.remove("dragging");
    draggedFood = null;
  });
});

// Eventos de soltar nas seções
document.querySelectorAll(".section").forEach((section) => {
  section.addEventListener("dragover", (e) => e.preventDefault());

  section.addEventListener("drop", () => {
    if (!draggedFood) return;

    const foodType = draggedFood.dataset.category;
    const sectionType = section.dataset.category;

    if (foodType === sectionType && !section.querySelector(".food")) {
      section.appendChild(draggedFood);
      score++;
      scoreDisplay.textContent = score;
      if (score === 5) {
        clearInterval(timerInterval);
        endGame();
      }
    } else {
      alert(
        "Esse alimento não pertence a essa categoria ou já foi preenchido."
      );
    }
  });
});

// Evento do botão de reinício
resetBtn.addEventListener("click", resetGame);

// Inicia o jogo ao carregar
startTimer();
