const gameContainer = document.getElementById("game-container");
const levelDisplay = document.getElementById("level-display");
const goalDisplay = document.getElementById("goal-display");
const timerDisplay = document.getElementById("timer-display");
const scoreDisplay = document.getElementById("score-display");

let level = 1;
let score = 0;
let goal = 5;
let timeLeft = 30;
let timer;
let insectInterval;

function startLevel() {
  updateHUD();
  score = 0;
  timeLeft = 30;
  updateScore();
  timer = setInterval(updateTimer, 1000);
  insectInterval = setInterval(spawnInsect, 1500);
}

function updateHUD() {
  levelDisplay.textContent = `Nível: ${level}`;
  goalDisplay.textContent = `Meta: Pegue ${goal} insetos`;
  timerDisplay.textContent = `Tempo: ${timeLeft}s`;
}

function updateScore() {
  scoreDisplay.textContent = `Pontos: ${score}`;
  if (score >= goal) {
    levelUp();
  }
}

function updateTimer() {
  timeLeft--;
  timerDisplay.textContent = `Tempo: ${timeLeft}s`;
  if (timeLeft <= 0) {
    endLevel(false);
  }
}

function spawnInsect() {
  const insect = document.createElement("div");
  insect.classList.add("insect");
  insect.style.top = `${Math.random() * (window.innerHeight - 60)}px`;
  insect.style.left = `${Math.random() * (window.innerWidth - 60)}px`;
  insect.innerHTML = `<img src="img/mosquito.jpg" alt="Inseto" />`;

  insect.addEventListener("click", () => {
    score++;
    updateScore();
    insect.remove();
  });

  gameContainer.appendChild(insect);
  setTimeout(() => insect.remove(), 3000);
}

function levelUp() {
  clearInterval(timer);
  clearInterval(insectInterval);
  showMessage(`🎉 Nível ${level} completo!`);
  setTimeout(() => {
    level++;
    goal += 5;
    startLevel();
  }, 3000);
}

function endLevel(success) {
  clearInterval(timer);
  clearInterval(insectInterval);
  if (!success) {
    showMessage(`⏱️ Tempo esgotado! Tente novamente.`);
    setTimeout(startLevel, 3000);
  }
}

function showMessage(text) {
  const msg = document.createElement("div");
  msg.classList.add("message");
  msg.textContent = text;
  document.body.appendChild(msg);
  setTimeout(() => msg.remove(), 2500);
}

// Iniciar o jogo
startLevel();
