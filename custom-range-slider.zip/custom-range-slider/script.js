const video = document.getElementById("myVideo");
const slider = document.getElementById("volumeSlider");
const label = document.getElementById("volumeLabel");

slider.addEventListener("input", () => {
  const volume = slider.value / 100;
  video.volume = volume;
  label.innerText = `Volume: ${slider.value}%`;
});
