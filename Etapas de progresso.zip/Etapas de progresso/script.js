const progress = document.getElementById("progress");
const prev = document.getElementById("prev");
const next = document.getElementById("next");
const circles = document.querySelectorAll(".circle");

// Descrições para cada etapa
const descriptions = [
  "Etapa 1: Início",
  "Etapa 2: Informações pessoais",
  "Etapa 3: Preferências",
  "Etapa 4: Data de nascimento",
  "Etapa 5: Telefone",
  "Etapa 6: Envio",
];

let currentActive = 1;

next.addEventListener("click", () => {
  currentActive++;
  if (currentActive > circles.length) {
    currentActive = circles.length;
  }
  update();
});

prev.addEventListener("click", () => {
  currentActive--;
  if (currentActive < 1) {
    currentActive = 1;
  }
  update();
});

function update() {
  // Atualiza os círculos
  circles.forEach((circle, idx) => {
    if (idx < currentActive) {
      circle.classList.add("active");
    } else {
      circle.classList.remove("active");
    }
  });

  // Atualiza a barra de progresso
  const actives = document.querySelectorAll(".active");
  progress.style.width =
    ((actives.length - 1) / (circles.length - 1)) * 100 + "%";

  // Atualiza a descrição da etapa
  document.getElementById("step-description").textContent =
    descriptions[currentActive - 1];

  // Atualiza o campo de formulário visível
  const steps = document.querySelectorAll(".form-step");
  steps.forEach((step, idx) => {
    step.classList.remove("active");
  });
  if (steps[currentActive - 1]) {
    steps[currentActive - 1].classList.add("active");
  }

  // Habilita/desabilita botões
  prev.disabled = currentActive === 1;
  next.disabled = currentActive === circles.length;
}
