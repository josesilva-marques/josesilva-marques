const navbar = document.querySelector(".navbar");

window.addEventListener("scroll", () => {
  if (window.scrolly > navbar.offsetHeight + 50) {
    navbar.classList.add("sticky");
  } else {
    navbar.classList.remove("sticky");
  }
});
