// Seleciona os elementos do DOM
const loadText = document.querySelector(".loading-text");
const bg = document.querySelector(".bg");

// Configurações personalizáveis
const maxBlur = 30; // Intensidade máxima do desfoque
const duration = 3000; // Duração total da animação em milissegundos
const steps = 100; // Número de etapas (de 0% a 100%)
const increment = 100 / steps;
const frameDelay = duration / steps;

let load = 0;
let lastTime = null;

function blurring(timestamp) {
  if (!lastTime) lastTime = timestamp;
  const elapsed = timestamp - lastTime;

  if (elapsed >= frameDelay) {
    load += increment;
    lastTime = timestamp;

    if (load >= 100) {
      load = 100;
      updateUI(load);
      onLoadComplete();
      return;
    }

    updateUI(load);
  }

  requestAnimationFrame(blurring);
}

// Atualiza os elementos visuais
function updateUI(load) {
  const rounded = Math.floor(load);
  loadText.innerText = `${rounded}%`;
  loadText.style.opacity = scale(load, 0, 100, 1, 0);
  bg.style.filter = `blur(${scale(load, 0, 100, maxBlur, 0)}px)`;
  loadText.setAttribute("aria-valuenow", rounded);
}

// Função chamada ao final do carregamento
function onLoadComplete() {
  console.log("Carregamento concluído!");
  // Aqui você pode iniciar outra animação, mostrar conteúdo, etc.
}

// Mapeia um número de um intervalo para outro
function scale(num, in_min, in_max, out_min, out_max) {
  return ((num - in_min) * (out_max - out_min)) / (in_max - in_min) + out_min;
}

// Inicia a animação
requestAnimationFrame(blurring);
