// Seleciona todos os botões com a classe 'ripple'
const buttons = document.querySelectorAll(".ripple");

// Função para criar o efeito ripple
function createRipple(event) {
  const button = event.currentTarget;

  // Calcula posição do clique relativa ao botão
  const rect = button.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const y = event.clientY - rect.top;

  // Cria o elemento da onda
  const circle = document.createElement("span");
  circle.classList.add("circle");
  circle.style.left = `${x}px`;
  circle.style.top = `${y}px`;

  // Adiciona e remove após 500ms
  button.appendChild(circle);
  setTimeout(() => circle.remove(), 500);
}

// Aplica o evento a cada botão
buttons.forEach((button) => {
  button.addEventListener("click", createRipple);
});
