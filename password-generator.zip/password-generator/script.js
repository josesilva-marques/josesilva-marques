/* Explicação: Isso é como nossa caixa de ferramentas com todas as letrinhas e símbolos */

const minusculas = "abcdefghijklmnopqrstuvwxyz"; // Letras pequenas
const maiusculas = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // Letras GRANDES
const numeros = "0123456789"; // Números
const simbolos = "!@#$%&*()_+-="; // Símbolos especiais

/* Explicação: Quando clicamos no botão, essa função cria a senha mágica */
function generatePassword() {
  // Pegamos as configurações que o usuário escolheu
  const comprimento = document.getElementById("lengthSlider").value;
  const includeUppercase = document.getElementById("uppercaseCheck").checked;
  const includeNumbers = document.getElementById("numbersCheck").checked;
  const includeSymbols = document.getElementById("symbolsCheck").checked;

  /* Começamos com as letras pequenas (sempre usamos) */
  let caracteres = minusculas;

  // Se o usuário quer letras GRANDES, adicionamos à nossa caixa de ferramentas
  if (includeUppercase) {
    caracteres += maiusculas;
  }

  // Se o usuário quer números, adicionamos à nossa caixa
  if (includeNumbers) {
    caracteres += numeros;
  }

  // Se o usuário quer símbolos, adicionamos à nossa caixa
  if (includeSymbols) {
    caracteres += simbolos;
  }

  // Agora vamos criar a senha, como construir com Lego!
  let senha = "";
  for (let i = 0; i < comprimento; i++) {
    // Escolhemos uma letra/símbolo aleatório da nossa caixa
    const randomIndex = Math.floor(Math.random() * caracteres.length);
    senha += caracteres[randomIndex];
  }

  // Mostramos a senha mágica na tela!
  document.getElementById("passwordDisplay").textContent = senha;
  document.getElementById("message").textContent = "";
}

/* Explicação: Essa função copia a senha para colar em outros lugares */
function copyPassword() {
  const senha = document.getElementById("passwordDisplay").textContent;

  // Só copiamos se já tiver uma senha gerada
  if (senha !== "Clique no botão para criar uma senha!") {
    navigator.clipboard.writeText(senha).then(() => {
      document.getElementById("message").textContent = "Senha copiada! ✨";

      // A mensagem some depois de 2 segundos
      setTimeout(() => {
        document.getElementById("message").textContent = "";
      }, 2000);
    });
  }
}
