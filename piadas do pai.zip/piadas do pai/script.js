// Seleciona os elementos HTML
const jokeEl = document.getElementById("joke");
const jokeBtn = document.getElementById("jokeBtn");

// Adiciona o evento de clique ao botão
jokeBtn.addEventListener("click", generateJoke);

// Exibe uma piada ao carregar a página
generateJoke();

// Função para buscar e exibir uma piada
async function generateJoke() {
  try {
    // Busca o arquivo JSON local
    const res = await fetch("piadas.json");
    const data = await res.json();

    // Escolhe uma piada aleatória
    const randomIndex = Math.floor(Math.random() * data.length);
    const joke = data[randomIndex];

    // Exibe a piada na tela
    jokeEl.innerHTML = `<strong>${joke.pergunta}</strong><br/>${joke.resposta}`;
  } catch (error) {
    jokeEl.innerHTML = "Ops! Não consegui carregar uma piada agora.";
    console.error("Erro ao buscar piada:", error);
  }
}
