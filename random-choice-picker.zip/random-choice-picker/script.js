// Seleção dos elementos
const tagsEl = document.getElementById("tags");
const textarea = document.getElementById("textarea");

textarea.focus();

// --- Funções utilitárias ---
function debounce(fn, delay) {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), delay);
  };
}

// --- Eventos ---
textarea.addEventListener("keyup", handleKeyUp);

function handleKeyUp(e) {
  createTags(e.target.value);

  if (e.key === "Enter") {
    e.preventDefault(); // impede quebra de linha
    e.target.value = "";
    randomSelect();
  }
}

// --- Funções principais ---
function createTags(input) {
  const tags = input
    .split(",")
    .map((tag) => tag.trim())
    .filter((tag) => tag !== "");

  if (!tags.length) {
    tagsEl.innerHTML = "";
    return;
  }

  // Substitui de forma mais performática
  tagsEl.replaceChildren(
    ...tags.map((tag) => {
      const span = document.createElement("span");
      span.className = "tag";
      span.textContent = tag;
      return span;
    })
  );
}

let lastTag = null;

function pickRandomTag() {
  const tags = document.querySelectorAll(".tag");
  if (!tags.length) return null;

  let randomTag;
  do {
    randomTag = tags[Math.floor(Math.random() * tags.length)];
  } while (randomTag === lastTag && tags.length > 1);

  lastTag = randomTag;
  return randomTag;
}

function highlightTag(tag) {
  tag.classList.add("highlight");
}

function unHighlightTag(tag) {
  tag.classList.remove("highlight");
}

function randomSelect() {
  const times = 30;
  let interval = setInterval(() => {
    const randomTag = pickRandomTag();
    if (!randomTag) return;

    highlightTag(randomTag);
    setTimeout(() => unHighlightTag(randomTag), 100);
  }, 100);

  setTimeout(() => {
    clearInterval(interval);

    setTimeout(() => {
      const randomTag = pickRandomTag();
      if (randomTag) highlightTag(randomTag);
    }, 100);
  }, times * 100);
}
