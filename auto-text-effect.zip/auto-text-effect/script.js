// A frase que queremos escrever
const frase = "Eu sou um programador Júnior";

// O lugar onde o texto vai aparecer (o quadro branco)
const quadro = document.getElementById("texto");

// Onde vamos guardar em que letra estamos
let indice = 0;

// A velocidade (quanto menor o número, mais rápido escreve)
let velocidade = 150; // 150 milissegundos

function escrever() {
  // Pega a parte da frase até a letra onde estamos
  quadro.innerText = frase.slice(0, indice);

  // Vai para a próxima letra
  indice++;

  // Se chegou no fim da frase, volta para o começo
  if (indice > frase.length) {
    indice = 0;
  }

  // Manda repetir a mágica depois de um tempinho
  setTimeout(escrever, velocidade);
}

// Começa a mágica ✨
escrever();
